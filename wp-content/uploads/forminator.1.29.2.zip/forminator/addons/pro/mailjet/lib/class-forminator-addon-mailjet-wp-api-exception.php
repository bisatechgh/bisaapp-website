<?php

/**
 * Class Forminator_Addon_Mailjet_Wp_Api_Exception
 * Exception holder for mailjet wp api
 */
class Forminator_Addon_Mailjet_Wp_Api_Exception extends Forminator_Addon_Mailjet_Exception {
}
