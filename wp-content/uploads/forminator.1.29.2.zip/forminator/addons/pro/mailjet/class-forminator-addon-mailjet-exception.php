<?php

/**
 * Class Forminator_Addon_Mailjet_Exception
 * Wrapper of Mailjet Exception
 */
class Forminator_Addon_Mailjet_Exception extends Exception {
}
