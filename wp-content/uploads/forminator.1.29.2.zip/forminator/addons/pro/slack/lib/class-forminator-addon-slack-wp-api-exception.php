<?php

/**
 * Class Forminator_Addon_Slack_Wp_Api_Exception
 * Exception holder for Slack wp api
 *
 * @since 1.0 Slack Addon
 */
class Forminator_Addon_Slack_Wp_Api_Exception extends Forminator_Addon_Slack_Exception {
}
