<?php

/**
 * Moved to Webhook integration.
 * Leave it here to avoid Fatal errors during updating plugin.
 * Remove zapier folder after several versions.
 */
class Forminator_Addon_Zapier_Form_Hooks extends Forminator_Addon_Form_Hooks_Abstract {

}
