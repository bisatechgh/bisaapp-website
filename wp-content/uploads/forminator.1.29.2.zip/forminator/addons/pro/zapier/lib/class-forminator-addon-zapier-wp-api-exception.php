<?php

/**
 * Moved to Webhook integration.
 * Leave it here to avoid Fatal errors during updating plugin.
 * Remove zapier folder after several versions.
 */
class Forminator_Addon_Zapier_Wp_Api_Exception extends Forminator_Addon_Zapier_Exception {
}
