<?php
/**
 * Class Forminator_Mailjet_Quiz_Settings
 * Form Settings Mailjet Process
 */
class Forminator_Mailjet_Quiz_Settings extends Forminator_Integration_Quiz_Settings {
	use Forminator_Mailjet_Settings_Trait;
}
