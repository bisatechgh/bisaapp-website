<?php

/**
 * Class Forminator_Mailjet_Quiz_Hooks
 *
 * Hooks that used by Mailjet Integration defined here
 */
class Forminator_Mailjet_Quiz_Hooks extends Forminator_Integration_Quiz_Hooks {
}
