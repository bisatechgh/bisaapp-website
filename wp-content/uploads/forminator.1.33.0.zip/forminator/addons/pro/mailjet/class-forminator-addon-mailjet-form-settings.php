<?php
/**
 * Class Forminator_Mailjet_Form_Settings
 * Form Settings Mailjet Process
 */
class Forminator_Mailjet_Form_Settings extends Forminator_Integration_Form_Settings {
	use Forminator_Mailjet_Settings_Trait;
}
