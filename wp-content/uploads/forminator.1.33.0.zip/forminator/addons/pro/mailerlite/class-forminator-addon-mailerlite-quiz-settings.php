<?php
/**
 * Class Forminator_Mailerlite_Quiz_Settings
 * Quiz Settings Mailerlite Process
 */
class Forminator_Mailerlite_Quiz_Settings extends Forminator_Integration_Quiz_Settings {
	use Forminator_Mailerlite_Settings_Trait;
}
