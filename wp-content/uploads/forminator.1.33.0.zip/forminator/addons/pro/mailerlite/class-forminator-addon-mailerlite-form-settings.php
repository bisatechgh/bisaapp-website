<?php
/**
 * Class Forminator_Mailerlite_Form_Settings
 * Form Settings Mailerlite Process
 */
class Forminator_Mailerlite_Form_Settings extends Forminator_Integration_Form_Settings {
	use Forminator_Mailerlite_Settings_Trait;
}
