<?php

/**
 * Class Forminator_Mailerlite_Form_Hooks
 *
 * Hooks that used by Mailerlite Integration defined here
 */
class Forminator_Mailerlite_Form_Hooks extends Forminator_Integration_Form_Hooks {
}
