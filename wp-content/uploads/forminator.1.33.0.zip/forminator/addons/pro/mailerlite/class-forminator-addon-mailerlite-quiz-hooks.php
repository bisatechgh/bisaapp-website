<?php

/**
 * Class Forminator_Mailerlite_Quiz_Hooks
 *
 * Hooks that used by Mailerlite Integration defined here
 */
class Forminator_Mailerlite_Quiz_Hooks extends Forminator_Integration_Quiz_Hooks {
}
